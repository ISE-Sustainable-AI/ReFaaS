import json

def basic_arithmetic(event, context):
    num1 = event.get('num1', 0)
    num2 = event.get('num2', 0)
    operation = event.get('operation', '@')
    
    if operation == '+':
        result = num1 + num2
    elif operation == '-':
        result = num1 - num2
    elif operation == '*':
        result = num1 * num2
    elif operation == '/':
        if num2 != 0:
            result = num1 / num2
        else:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Division by zero'})
            }
    else:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'Invalid operation'})
        }
    
    return {
        'statusCode': 200,
        'body': json.dumps({'result': result})
    }

def lambda_handler(event, context):
    return basic_arithmetic(event, context)